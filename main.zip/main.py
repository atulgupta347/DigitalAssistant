#imports
import wolframalpha
import wikipedia
import pyttsx3
import speech_recognition as sr
import tkinter as tk
from tkinter import *
from tkinter import messagebox

#GUI Window
window=Tk()
window.title('Digital Assistant')
window.geometry('500x100')
window.resizable(0,0)
window.configure(bg='white')

#Title Label
Label(window,text ='Hello I am Python Digital Assistant, How can I help you?',relief = tk.FLAT, font="Helvetica,36,bold",
      bg='white', fg='orange').pack()

#Query
input=Entry(window, bd=3, relief=tk.RIDGE, justify=tk.LEFT,fg = 'orange')
input.place(x=65,y=30,width=350)

#Output
msg=Text(window, fg="orange",bg='white', relief=tk.FLAT)
msg.place(x=70,y=90,width=350)
msg.configure(state='disabled')

#Listen query using microphone
def listenAudio():
    input.configure(state='disabled')
    engine = pyttsx3.init()
    engine.say('I am listening')
    engine.runAndWait()
    r = sr.Recognizer()
    with sr.Microphone() as source:
        audio = r.listen(source)
        try:
            text=r.recognize_google(audio)
            input.configure(state='normal')
            input.delete(0,'end')
            input.insert(0,text)
            input.configure(state='disabled')
        except sr.UnknownValueError:
            messagebox.showerror("Error","Couln't understand")
        except sr.RequestError as e:
            messagebox.showerror("Error", format(e))

#Button for Audio
Button(window, text="Use Audio", fg="orange", command=listenAudio).place(x=430,y=27)

#Search the query and Update the output
def Search():
    query = input.get()
    query = query.lower()
    try:
        app_id= "XXXXXX-XXXXXXXXXX"
        client = wolframalpha.Client(app_id)
        res = client.query(query)
        answer = next(res.results).text
    except:
        try:
            answer = wikipedia.summary(query, sentences=2)
        except:
            answer ="No Idea, Please rephrase the query."
            messagebox.showerror("Error", 'No Idea, Please rephrase the query.')

    window.geometry('500x300')
    msg.configure(state='normal')
    msg.delete(1.0, "end")
    msg.insert(1.0, answer)
    msg.configure(state='disabled')
    engine = pyttsx3.init()
    engine.say(answer)
    engine.runAndWait()
    input.configure(state='normal')

#Button for search
Button(window, text="Search", fg="orange", command=Search).place(x=200,y=60)

#caller
if __name__=="__main__":
    window.mainloop()